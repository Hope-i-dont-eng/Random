export function ProductFrame() {
  return (
    <div
      className="rounded-xl bg-card p-2 shadow-[var(--shadow-elevated)]"
      aria-hidden="true"
    >
      <div className="overflow-hidden rounded-lg bg-background shadow-[var(--shadow-border)]">
        <div className="flex items-center gap-3 border-b border-border px-3 py-2.5">
          <div className="flex gap-1.5">
            <span className="size-2.5 rounded-full bg-secondary" />
            <span className="size-2.5 rounded-full bg-secondary" />
            <span className="size-2.5 rounded-full bg-secondary" />
          </div>
          <p className="flex-1 truncate text-center text-xs text-muted-foreground">
            Local 1 — Northwind vault
          </p>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-2 py-0.5 text-xs font-medium text-foreground">
            <span className="size-1.5 rounded-full bg-primary" />
            Private
          </span>
        </div>
        <div className="product-frame-grid">
          <aside className="border-r border-border bg-muted/60 p-3">
            <p className="mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase">
              Vaults
            </p>
            <ul className="space-y-1 text-xs">
              <li className="rounded-sm bg-accent px-2 py-1.5 text-foreground">Northwind</li>
              <li className="rounded-sm px-2 py-1.5 text-muted-foreground">Clinic notes</li>
              <li className="rounded-sm px-2 py-1.5 text-muted-foreground">Source</li>
            </ul>
            <p className="mt-5 mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase">
              Model
            </p>
            <p className="rounded-sm bg-secondary px-2 py-1.5 text-xs text-foreground">
              Qwen 2.5 32B
            </p>
            <p className="mt-2 px-2 text-xs text-muted-foreground">On this machine</p>
          </aside>
          <div className="flex flex-col gap-3 p-4 sm:p-5">
            <div className="max-w-sm self-end rounded-lg rounded-br-xs bg-secondary px-3 py-2 text-xs leading-relaxed text-foreground sm:text-sm">
              Summarize the indemnification clause in 8.2. Do not send this file anywhere.
            </div>
            <div className="max-w-md rounded-lg rounded-bl-xs bg-muted px-3 py-2.5 text-xs leading-relaxed text-foreground sm:text-sm">
              <p className="mb-1.5 text-xs font-medium text-muted-foreground">
                Local 1 · 38 tok/s · 0 bytes outbound
              </p>
              Section 8.2 caps indemnity at twelve months of fees, excludes consequential
              damages, and requires written notice within 15 days. The cap does not apply
              to IP infringement or willful misconduct.
              <span className="mt-2 block text-xs text-muted-foreground">
                Cited: brief.pdf p.14 · addendum p.3
              </span>
            </div>
            <div className="mt-auto flex items-center gap-2 rounded-md bg-secondary px-3 py-2 text-xs text-muted-foreground shadow-[var(--shadow-border)]">
              <span className="flex-1">Ask this vault…</span>
              <span className="rounded-sm bg-primary px-2 py-0.5 text-xs font-medium text-primary-foreground">
                Run
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
