import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <a
      href="#top"
      className={cn(
        "inline-flex items-center gap-2.5 text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring/70",
        className,
      )}
      aria-label="Local 1 home"
    >
      <span className="flex size-8 items-center justify-center rounded-sm bg-primary text-primary-foreground">
        <svg viewBox="0 0 20 20" className="size-4" aria-hidden="true">
          <path
            d="M8.2 3.2h2.15v11.2H15V16.8H5.1v-2.4h3.1V3.2Z"
            fill="currentColor"
          />
        </svg>
      </span>
      <span className="font-display text-xl leading-none tracking-tight">
        Local 1
      </span>
    </a>
  );
}
