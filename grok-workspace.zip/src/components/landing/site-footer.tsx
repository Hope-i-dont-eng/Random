import { Logo } from "@/components/landing/logo";
import { Button } from "@/components/ui/button";

const COLUMNS = [
  {
    title: "Product",
    links: [
      { href: "#product", label: "Overview" },
      { href: "#features", label: "Features" },
      { href: "#pricing", label: "Pricing" },
    ],
  },
  {
    title: "Company",
    links: [
      { href: "#stories", label: "Stories" },
      { href: "#access", label: "Private preview" },
    ],
  },
] as const;

export function SiteFooter() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-6xl flex-col gap-10 px-5 py-12 md:flex-row md:items-start md:justify-between md:px-6 md:py-16">
        <div className="max-w-sm">
          <Logo />
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
            Private AI for machines you already own. Local 1 keeps the work in
            the room.
          </p>
          <Button asChild className="mt-6">
            <a href="#access">Request access</a>
          </Button>
        </div>
        <div className="flex gap-16">
          {COLUMNS.map((column) => (
            <div key={column.title}>
              <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
                {column.title}
              </p>
              <ul className="mt-3 space-y-2">
                {column.links.map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      className="text-sm text-foreground hover:text-muted-foreground"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
      <div className="border-t border-border">
        <p className="mx-auto max-w-6xl px-5 py-5 text-xs text-muted-foreground md:px-6">
          © {new Date().getFullYear()} Local 1. Models run on your hardware. We
          do not train on your vault.
        </p>
      </div>
    </footer>
  );
}
