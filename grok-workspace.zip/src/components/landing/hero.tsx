import { ArrowRight } from "lucide-react";
import { ProductFrame } from "@/components/landing/product-frame";
import { Button } from "@/components/ui/button";

export function Hero() {
  return (
    <section
      id="product"
      className="relative overflow-hidden border-b border-border bg-hero-wash"
    >
      <div
        className="hero-wash pointer-events-none absolute inset-0"
        aria-hidden="true"
      />
      <div
        className="noise-bg pointer-events-none absolute inset-0 opacity-5 mix-blend-overlay"
        aria-hidden="true"
      />
      <div className="relative mx-auto grid max-w-6xl gap-12 px-5 py-16 md:px-6 md:py-24 lg:grid-cols-2 lg:items-center lg:gap-16 lg:py-28">
        <div className="stagger-in">
          <p className="text-sm font-medium tracking-wide text-muted-foreground">
            Private preview · macOS, Windows, Linux
          </p>
          <h1 className="mt-5 font-display text-display text-foreground">
            The AI that stays in the room.
          </h1>
          <p className="mt-6 max-w-xl text-lead text-muted-foreground">
            Local 1 runs serious models on the hardware you already own. Briefs,
            records, and source never leave the machine. The cloud does not get a
            copy.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
            <Button asChild size="lg" className="pl-6 pr-5">
              <a href="#access">
                Request access
                <ArrowRight className="size-4" />
              </a>
            </Button>
            <Button asChild size="lg" variant="outline">
              <a href="#features">See how it works</a>
            </Button>
          </div>
          <dl className="mt-10 grid grid-cols-3 gap-4 border-t border-border pt-6 max-w-lg">
            <div>
              <dt className="text-xs text-muted-foreground">Outbound</dt>
              <dd className="mt-1 font-display text-xl text-foreground">0 bytes</dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">First token</dt>
              <dd className="mt-1 font-display text-xl text-foreground">{"<40 ms"}</dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Install</dt>
              <dd className="mt-1 font-display text-xl text-foreground">One app</dd>
            </div>
          </dl>
        </div>
        <ProductFrame />
      </div>
    </section>
  );
}
