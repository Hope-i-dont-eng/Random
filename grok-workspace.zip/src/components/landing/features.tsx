import {
  Bot,
  Cable,
  Cpu,
  FolderLock,
  Shield,
  WifiOff,
} from "lucide-react";
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const REASONS = [
  {
    num: "01",
    title: "Nothing leaves the subnet",
    body: "Models, prompts, and files stay on this machine or a box you rack. There is no tenant, no training opt-out, no “we don’t look.”",
  },
  {
    num: "02",
    title: "The round trip is memory, not a region",
    body: "First tokens come from local weights. Counsel, clinicians, and engineers get an answer before a cloud request would even handshake.",
  },
  {
    num: "03",
    title: "One license. Unlimited prompts.",
    body: "You are not metered for thinking. Run overnight jobs, whole-repo reviews, and every draft without watching a usage graph.",
  },
] as const;

const FEATURES = [
  {
    icon: Cpu,
    title: "On-device models",
    body: "Ship a CPU path first. Apple Silicon, NVIDIA, AMD, or the laptop you already carry. Swap weights without leaving the app.",
  },
  {
    icon: FolderLock,
    title: "Encrypted vault",
    body: "Drop briefs, charts, and repos into a vault encrypted at rest. Retrieval never uploads. Citations point at local pages.",
  },
  {
    icon: WifiOff,
    title: "Offline by default",
    body: "Airplane mode is a supported environment. Sync is optional, explicit, and never implied by a progress spinner.",
  },
  {
    icon: Cable,
    title: "OpenAI-compatible API",
    body: "Point existing tools at localhost. Same shapes, your hardware. Keep the editors and agents you already paid for.",
  },
  {
    icon: Bot,
    title: "Local agents",
    body: "Agents that read the filesystem, run commands you approve, and write back into the vault — without a remote callback.",
  },
  {
    icon: Shield,
    title: "Firm controls",
    body: "Seat-based admin, air-gapped installers, and an audit log that lives next to the data, not in a vendor console.",
  },
] as const;

export function Features() {
  return (
    <section id="features" className="border-b border-border">
      <div className="mx-auto max-w-6xl px-5 py-20 md:px-6 md:py-28">
        <div className="max-w-2xl">
          <p className="text-sm font-medium tracking-wide text-muted-foreground">Why teams switch</p>
          <h2 className="mt-3 font-display text-title text-foreground">
            Cloud AI is someone else’s computer.
          </h2>
          <p className="mt-4 text-lead text-muted-foreground">
            Local 1 is a workspace for people who cannot send the work out. Same
            quality of answer. A different place for the weights to live.
          </p>
        </div>

        <ol className="mt-12 grid gap-4 md:grid-cols-3">
          {REASONS.map((reason) => (
            <li
              key={reason.num}
              className="rounded-xl bg-card p-6 shadow-[var(--shadow-border)]"
            >
              <p className="font-display text-2xl text-muted-foreground">{reason.num}</p>
              <h3 className="mt-4 text-lg font-medium text-foreground">{reason.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{reason.body}</p>
            </li>
          ))}
        </ol>

        <div className="mt-20 max-w-2xl">
          <p className="text-sm font-medium tracking-wide text-muted-foreground">The workspace</p>
          <h2 className="mt-3 font-display text-title text-foreground">
            Everything you need, nothing you upload.
          </h2>
        </div>

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((feature) => (
            <Card key={feature.title} className="rounded-xl p-2">
              <CardHeader className="rounded-lg bg-muted/50 p-5">
                <span className="flex size-10 items-center justify-center rounded-md bg-secondary text-foreground shadow-[var(--shadow-border)]">
                  <feature.icon className="size-4" strokeWidth={1.75} />
                </span>
                <CardTitle className="mt-4 text-base">{feature.title}</CardTitle>
                <CardDescription>{feature.body}</CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
