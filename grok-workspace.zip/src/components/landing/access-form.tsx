import { useEffect, useMemo, useState, type FormEvent } from "react";
import { Check } from "lucide-react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getWaitlist, saveWaitlist, subscribeWaitlist, getSelectedPlan, subscribePlan, type WaitlistEntry } from "@/lib/waitlist";
import { cn } from "@/lib/utils";

const emailSchema = z.string().trim().email("Use a valid work email.");

const PLANS = [
  { id: "solo", label: "Solo" },
  { id: "pro", label: "Pro" },
  { id: "firm", label: "Firm" },
] as const;

export function AccessForm() {
  const [email, setEmail] = useState("");
  const [plan, setPlan] = useState<WaitlistEntry["plan"]>("pro");
  const [error, setError] = useState<string | null>(null);
  const [entry, setEntry] = useState<WaitlistEntry | null>(null);

  useEffect(() => {
    setEntry(getWaitlist());
    setPlan(getSelectedPlan());
    const sync = () => setEntry(getWaitlist());
    const unsub = subscribeWaitlist(sync);
    const unsubPlan = subscribePlan(setPlan);
    return () => {
      unsub();
      unsubPlan();
    };
  }, []);

  const heading = useMemo(
    () => (entry ? "You are on the list." : "Run Local 1 on the next brief."),
    [entry],
  );

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const parsed = emailSchema.safeParse(email);
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? "Check the email and try again.");
      return;
    }
    const next: WaitlistEntry = {
      email: parsed.data.toLowerCase(),
      plan,
      createdAt: new Date().toISOString(),
    };
    saveWaitlist(next);
    setEntry(next);
    setError(null);
  }

  return (
    <section id="access" className="border-b border-border">
      <div className="mx-auto max-w-6xl px-5 py-20 md:px-6 md:py-28">
        <div className="rounded-xl bg-card px-6 py-12 shadow-[var(--shadow-elevated)] md:px-12 md:py-16">
          <div className="mx-auto max-w-xl">
            <p className="text-sm font-medium tracking-wide text-muted-foreground">Private preview</p>
            <h2 className="mt-3 font-display text-title text-foreground">{heading}</h2>
            <p className="mt-4 text-lead text-muted-foreground">
              {entry
                ? `We will write ${entry.email} when the ${entry.plan} build is ready for your machine.`
                : "Leave a work email. We send one note when your build is ready — macOS, Windows, or Linux."}
            </p>

            {entry ? (
              <div className="mt-8 flex items-start gap-3 rounded-lg bg-secondary p-4 shadow-[var(--shadow-border)]">
                <span className="flex size-10 shrink-0 items-center justify-center rounded-md bg-primary text-primary-foreground">
                  <Check className="size-4" strokeWidth={2} />
                </span>
                <p className="text-sm leading-relaxed text-foreground">
                  Seat reserved on the {entry.plan} list. Keep this tab if you want to
                  change nothing — we already have you.
                </p>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="mt-8 space-y-5" noValidate>
                <fieldset>
                  <legend className="mb-2 text-sm font-medium text-foreground">Plan</legend>
                  <div className="grid grid-cols-3 gap-2">
                    {PLANS.map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setPlan(item.id)}
                        className={cn(
                          "h-11 rounded-md text-sm font-medium shadow-[var(--shadow-border)] transition-[background-color,color] duration-150 ease-out",
                          plan === item.id
                            ? "bg-primary text-primary-foreground"
                            : "bg-secondary text-muted-foreground hover:text-foreground",
                        )}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </fieldset>
                <div className="space-y-2">
                  <Label htmlFor="waitlist-email">Work email</Label>
                  <div className="flex flex-col gap-3 sm:flex-row">
                    <Input
                      id="waitlist-email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      inputMode="email"
                      placeholder="you@firm.com"
                      value={email}
                      onChange={(event) => {
                        setEmail(event.target.value);
                        if (error) setError(null);
                      }}
                      aria-invalid={Boolean(error)}
                      aria-describedby={error ? "waitlist-error" : undefined}
                      className="sm:flex-1"
                    />
                    <Button type="submit" className="sm:px-6">
                      Join the preview
                    </Button>
                  </div>
                  {error ? (
                    <p id="waitlist-error" className="text-sm text-destructive">
                      {error}
                    </p>
                  ) : (
                    <p className="text-xs text-muted-foreground">
                      No marketing sequence. One email when the build ships.
                    </p>
                  )}
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
