import { useState } from "react";
import { Check } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { selectPlan } from "@/lib/waitlist";
import { cn } from "@/lib/utils";

const TIERS = [
  {
    id: "solo" as const,
    name: "Solo",
    monthly: 0,
    yearly: 0,
    blurb: "For personal briefs and late-night drafting.",
    cta: "Start free",
    featured: false,
    features: [
      "1 seat, 1 machine",
      "Community models up to 14B",
      "Personal encrypted vault",
      "Offline chat",
      "Local OpenAI-compatible API",
    ],
  },
  {
    id: "pro" as const,
    name: "Pro",
    monthly: 24,
    yearly: 19,
    blurb: "For counsel, founders, and staff engineers.",
    cta: "Start Pro",
    featured: true,
    features: [
      "Everything in Solo",
      "Frontier local models",
      "Agents and approved tools",
      "Unlimited vault size",
      "Priority model updates",
    ],
  },
  {
    id: "firm" as const,
    name: "Firm",
    monthly: 48,
    yearly: 38,
    blurb: "For rooms that already have a lock on the door.",
    cta: "Talk to us",
    featured: false,
    features: [
      "Everything in Pro",
      "Shared vault on your LAN",
      "Admin, seats, and audit log",
      "Air-gapped installer",
      "Named success engineer",
    ],
  },
] as const;

export function Pricing() {
  const [yearly, setYearly] = useState(true);

  return (
    <section id="pricing" className="border-b border-border">
      <div className="mx-auto max-w-6xl px-5 py-20 md:px-6 md:py-28">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-medium tracking-wide text-muted-foreground">Pricing</p>
          <h2 className="mt-3 font-display text-title text-foreground">
            Pay for the seat. Not the thought.
          </h2>
          <p className="mt-4 text-lead text-muted-foreground">
            Run as many prompts as the machine will take. Cancel anytime. Firm
            includes an air-gapped build.
          </p>
          <div className="mt-8 inline-flex rounded-lg bg-secondary p-1 shadow-[var(--shadow-border)]">
            <button
              type="button"
              onClick={() => setYearly(false)}
              className={cn(
                "h-11 min-w-28 rounded-md px-4 text-sm font-medium transition-[background-color,color] duration-150 ease-out",
                !yearly ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground",
              )}
            >
              Monthly
            </button>
            <button
              type="button"
              onClick={() => setYearly(true)}
              className={cn(
                "h-11 min-w-28 rounded-md px-4 text-sm font-medium transition-[background-color,color] duration-150 ease-out",
                yearly ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground",
              )}
            >
              Yearly
            </button>
          </div>
        </div>

        <div className="mt-12 grid gap-4 lg:grid-cols-3">
          {TIERS.map((tier) => {
            const price = yearly ? tier.yearly : tier.monthly;
            const href = "#access";
            return (
              <Card
                key={tier.id}
                className={cn(
                  "flex flex-col rounded-xl p-2",
                  tier.featured && "bg-secondary",
                )}
              >
                <CardHeader className={cn("rounded-lg p-6", tier.featured ? "bg-card" : "bg-muted/40")}>
                  <div className="flex items-center justify-between gap-3">
                    <CardTitle className="text-lg">{tier.name}</CardTitle>
                    {tier.featured ? <Badge variant="primary">Most chosen</Badge> : null}
                  </div>
                  <CardDescription className="mt-1">{tier.blurb}</CardDescription>
                  <p className="mt-6 flex items-baseline gap-1 text-foreground">
                    <span className="font-display text-5xl tracking-tight tabular-nums">${price}</span>
                    <span className="text-sm text-muted-foreground">
                      {tier.id === "firm" ? "/seat/mo" : "/mo"}
                    </span>
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {price === 0
                      ? "No card. Community models."
                      : yearly
                        ? "Billed annually."
                        : "Billed monthly."}
                  </p>
                </CardHeader>
                <CardContent className="flex flex-1 flex-col px-6 pt-6">
                  <ul className="space-y-2.5">
                    {tier.features.map((item) => (
                      <li key={item} className="flex items-start gap-2.5 text-sm text-foreground">
                        <Check className="mt-0.5 size-4 shrink-0 text-muted-foreground" strokeWidth={1.75} />
                        {item}
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter className="px-6 pb-6">
                  <Button asChild className="w-full" variant={tier.featured ? "default" : "outline"}>
                    <a href={href} onClick={() => selectPlan(tier.id)}>
                      {tier.cta}
                    </a>
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
