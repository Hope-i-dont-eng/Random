import { Card } from "@/components/ui/card";

const STORIES = [
  {
    quote:
      "We stopped pasting contracts into a browser. Local 1 reads the vault on a Mac Mini in the war room. Opposing counsel still thinks we hired another associate.",
    name: "Mara Ellison",
    role: "General Counsel",
    firm: "Hale & Voss LLP",
    initials: "ME",
  },
  {
    quote:
      "Clinic notes cannot leave the building. The 32B model on our office tower is slower than the cloud — and that is an acceptable sentence to say out loud in a board meeting.",
    name: "Dr. Rohan Iyer",
    role: "Medical Director",
    firm: "Northline Health",
    initials: "RI",
  },
  {
    quote:
      "I pointed our internal tools at localhost and deleted three SaaS invoices. Same API shape. The weights live next to the CNC programs.",
    name: "Elena Voss",
    role: "Staff Engineer",
    firm: "Fieldline Manufacturing",
    initials: "EV",
  },
] as const;

export function Testimonials() {
  return (
    <section id="stories" className="border-b border-border">
      <div className="mx-auto max-w-6xl px-5 py-20 md:px-6 md:py-28">
        <div className="max-w-2xl">
          <p className="text-sm font-medium tracking-wide text-muted-foreground">Stories</p>
          <h2 className="mt-3 font-display text-title text-foreground">
            Built for rooms with a lock on the door.
          </h2>
          <p className="mt-4 text-lead text-muted-foreground">
            Counsel, clinicians, and operators who cannot file a vendor DPIA every
            time they want a second pair of eyes.
          </p>
        </div>
        <div className="mt-12 grid gap-4 lg:grid-cols-3">
          {STORIES.map((story) => (
            <Card key={story.name} className="flex flex-col rounded-xl p-6">
              <blockquote className="flex-1 text-sm leading-relaxed text-foreground">
                {story.quote}
              </blockquote>
              <footer className="mt-8 flex items-center gap-3">
                <span className="flex size-10 items-center justify-center rounded-md bg-secondary font-medium text-sm text-foreground shadow-[var(--shadow-border)]">
                  {story.initials}
                </span>
                <span>
                  <span className="block text-sm font-medium text-foreground">{story.name}</span>
                  <span className="block text-xs text-muted-foreground">
                    {story.role}, {story.firm}
                  </span>
                </span>
              </footer>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
