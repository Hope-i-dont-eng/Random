import { createFileRoute } from "@tanstack/react-router";
import { AccessForm } from "@/components/landing/access-form";
import { Features } from "@/components/landing/features";
import { Hero } from "@/components/landing/hero";
import { Pricing } from "@/components/landing/pricing";
import { SiteFooter } from "@/components/landing/site-footer";
import { SiteNav } from "@/components/landing/site-nav";
import { Testimonials } from "@/components/landing/testimonials";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <div id="top" className="min-h-dvh bg-background text-foreground">
      <SiteNav />
      <main>
        <Hero />
        <Features />
        <Pricing />
        <Testimonials />
        <AccessForm />
      </main>
      <SiteFooter />
    </div>
  );
}
