const KEY = "local1-waitlist";
const PLAN_KEY = "local1-plan";

export type PlanId = "solo" | "pro" | "firm";

export type WaitlistEntry = {
  email: string;
  plan: PlanId;
  createdAt: string;
};

export function getWaitlist(): WaitlistEntry | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as WaitlistEntry;
    if (!parsed.email) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function saveWaitlist(entry: WaitlistEntry) {
  localStorage.setItem(KEY, JSON.stringify(entry));
  window.dispatchEvent(new Event("local1-waitlist"));
}

export function subscribeWaitlist(onStore: () => void) {
  window.addEventListener("storage", onStore);
  window.addEventListener("local1-waitlist", onStore);
  return () => {
    window.removeEventListener("storage", onStore);
    window.removeEventListener("local1-waitlist", onStore);
  };
}

export function getSelectedPlan(): PlanId {
  if (typeof window === "undefined") return "pro";
  const stored = sessionStorage.getItem(PLAN_KEY);
  if (stored === "solo" || stored === "pro" || stored === "firm") return stored;
  return "pro";
}

export function selectPlan(plan: PlanId) {
  sessionStorage.setItem(PLAN_KEY, plan);
  window.dispatchEvent(new CustomEvent("local1-plan", { detail: plan }));
}

export function subscribePlan(onPlan: (plan: PlanId) => void) {
  const handler = (event: Event) => {
    const detail = (event as CustomEvent<PlanId>).detail;
    if (detail === "solo" || detail === "pro" || detail === "firm") onPlan(detail);
  };
  window.addEventListener("local1-plan", handler);
  return () => window.removeEventListener("local1-plan", handler);
}
