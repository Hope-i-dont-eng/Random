import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Menu, c as Check, d as ArrowRight, i as Shield, l as Cable, n as WifiOff, o as FolderLock, s as Cpu, t as X, u as Bot } from "../_libs/lucide-react.mjs";
import { i as string } from "../_libs/zod.mjs";
import { a as DialogOverlay, c as DialogTrigger, d as Slot, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DhF3AU9w.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium outline-none focus-visible:ring-2 focus-visible:ring-ring/70 focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 [&_svg]:shrink-0 transition-[background-color,color,box-shadow,opacity,transform] duration-150 ease-out active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			secondary: "bg-secondary text-secondary-foreground shadow-[var(--shadow-border)] hover:bg-accent",
			outline: "bg-transparent text-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)] hover:bg-accent/60",
			ghost: "bg-transparent text-foreground hover:bg-accent",
			link: "text-foreground underline-offset-4 hover:underline"
		},
		size: {
			default: "h-11 min-h-11 px-4",
			sm: "h-9 min-h-9 rounded-sm px-3",
			lg: "h-12 min-h-12 rounded-lg px-6 text-base",
			icon: "size-11 min-h-11 min-w-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		ref,
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
});
Button.displayName = "Button";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		ref,
		type,
		"data-slot": "input",
		className: cn("h-11 w-full min-w-0 rounded-md bg-secondary px-3.5 text-base text-foreground outline-none shadow-[var(--shadow-border)] placeholder:text-muted-foreground md:text-sm", "transition-[box-shadow,background-color] duration-150 ease-out", "focus-visible:shadow-[var(--shadow-border-hover)] focus-visible:ring-2 focus-visible:ring-ring/50", "disabled:pointer-events-none disabled:opacity-40", className),
		...props
	});
});
Input.displayName = "Input";
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	"data-slot": "label",
	className: cn("text-sm font-medium leading-none text-foreground peer-disabled:cursor-not-allowed peer-disabled:opacity-40", className),
	...props
}));
Label.displayName = Root.displayName;
var KEY = "local1-waitlist";
var PLAN_KEY = "local1-plan";
function getWaitlist() {
	if (typeof window === "undefined") return null;
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!parsed.email) return null;
		return parsed;
	} catch {
		return null;
	}
}
function saveWaitlist(entry) {
	localStorage.setItem(KEY, JSON.stringify(entry));
	window.dispatchEvent(new Event("local1-waitlist"));
}
function subscribeWaitlist(onStore) {
	window.addEventListener("storage", onStore);
	window.addEventListener("local1-waitlist", onStore);
	return () => {
		window.removeEventListener("storage", onStore);
		window.removeEventListener("local1-waitlist", onStore);
	};
}
function getSelectedPlan() {
	if (typeof window === "undefined") return "pro";
	const stored = sessionStorage.getItem(PLAN_KEY);
	if (stored === "solo" || stored === "pro" || stored === "firm") return stored;
	return "pro";
}
function selectPlan(plan) {
	sessionStorage.setItem(PLAN_KEY, plan);
	window.dispatchEvent(new CustomEvent("local1-plan", { detail: plan }));
}
function subscribePlan(onPlan) {
	const handler = (event) => {
		const detail = event.detail;
		if (detail === "solo" || detail === "pro" || detail === "firm") onPlan(detail);
	};
	window.addEventListener("local1-plan", handler);
	return () => window.removeEventListener("local1-plan", handler);
}
var emailSchema = string().trim().email("Use a valid work email.");
var PLANS = [
	{
		id: "solo",
		label: "Solo"
	},
	{
		id: "pro",
		label: "Pro"
	},
	{
		id: "firm",
		label: "Firm"
	}
];
function AccessForm() {
	const [email, setEmail] = (0, import_react.useState)("");
	const [plan, setPlan] = (0, import_react.useState)("pro");
	const [error, setError] = (0, import_react.useState)(null);
	const [entry, setEntry] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setEntry(getWaitlist());
		setPlan(getSelectedPlan());
		const sync = () => setEntry(getWaitlist());
		const unsub = subscribeWaitlist(sync);
		const unsubPlan = subscribePlan(setPlan);
		return () => {
			unsub();
			unsubPlan();
		};
	}, []);
	const heading = (0, import_react.useMemo)(() => entry ? "You are on the list." : "Run Local 1 on the next brief.", [entry]);
	function onSubmit(event) {
		event.preventDefault();
		const parsed = emailSchema.safeParse(email);
		if (!parsed.success) {
			setError(parsed.error.issues[0]?.message ?? "Check the email and try again.");
			return;
		}
		const next = {
			email: parsed.data.toLowerCase(),
			plan,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		saveWaitlist(next);
		setEntry(next);
		setError(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "access",
		className: "border-b border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-6xl px-5 py-20 md:px-6 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl bg-card px-6 py-12 shadow-[var(--shadow-elevated)] md:px-12 md:py-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium tracking-wide text-muted-foreground",
							children: "Private preview"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-title text-foreground",
							children: heading
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-lead text-muted-foreground",
							children: entry ? `We will write ${entry.email} when the ${entry.plan} build is ready for your machine.` : "Leave a work email. We send one note when your build is ready — macOS, Windows, or Linux."
						}),
						entry ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex items-start gap-3 rounded-lg bg-secondary p-4 shadow-[var(--shadow-border)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-10 shrink-0 items-center justify-center rounded-md bg-primary text-primary-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "size-4",
									strokeWidth: 2
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm leading-relaxed text-foreground",
								children: [
									"Seat reserved on the ",
									entry.plan,
									" list. Keep this tab if you want to change nothing — we already have you."
								]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit,
							className: "mt-8 space-y-5",
							noValidate: true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "mb-2 text-sm font-medium text-foreground",
								children: "Plan"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-3 gap-2",
								children: PLANS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setPlan(item.id),
									className: cn("h-11 rounded-md text-sm font-medium shadow-[var(--shadow-border)] transition-[background-color,color] duration-150 ease-out", plan === item.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"),
									children: item.label
								}, item.id))
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "waitlist-email",
										children: "Work email"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col gap-3 sm:flex-row",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "waitlist-email",
											name: "email",
											type: "email",
											autoComplete: "email",
											inputMode: "email",
											placeholder: "you@firm.com",
											value: email,
											onChange: (event) => {
												setEmail(event.target.value);
												if (error) setError(null);
											},
											"aria-invalid": Boolean(error),
											"aria-describedby": error ? "waitlist-error" : void 0,
											className: "sm:flex-1"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "submit",
											className: "sm:px-6",
											children: "Join the preview"
										})]
									}),
									error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										id: "waitlist-error",
										className: "text-sm text-destructive",
										children: error
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "No marketing sequence. One email when the build ships."
									})
								]
							})]
						})
					]
				})
			})
		})
	});
}
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "card",
		className: cn("rounded-xl bg-card text-card-foreground shadow-[var(--shadow-border)]", className),
		...props
	});
}
function CardHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "card-header",
		className: cn("flex flex-col gap-1.5 p-6", className),
		...props
	});
}
function CardTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		"data-slot": "card-title",
		className: cn("font-medium leading-snug text-foreground", className),
		...props
	});
}
function CardDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		"data-slot": "card-description",
		className: cn("text-sm leading-relaxed text-muted-foreground", className),
		...props
	});
}
function CardContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "card-content",
		className: cn("p-6 pt-0", className),
		...props
	});
}
function CardFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "card-footer",
		className: cn("flex items-center p-6 pt-0", className),
		...props
	});
}
var REASONS = [
	{
		num: "01",
		title: "Nothing leaves the subnet",
		body: "Models, prompts, and files stay on this machine or a box you rack. There is no tenant, no training opt-out, no “we don’t look.”"
	},
	{
		num: "02",
		title: "The round trip is memory, not a region",
		body: "First tokens come from local weights. Counsel, clinicians, and engineers get an answer before a cloud request would even handshake."
	},
	{
		num: "03",
		title: "One license. Unlimited prompts.",
		body: "You are not metered for thinking. Run overnight jobs, whole-repo reviews, and every draft without watching a usage graph."
	}
];
var FEATURES = [
	{
		icon: Cpu,
		title: "On-device models",
		body: "Ship a CPU path first. Apple Silicon, NVIDIA, AMD, or the laptop you already carry. Swap weights without leaving the app."
	},
	{
		icon: FolderLock,
		title: "Encrypted vault",
		body: "Drop briefs, charts, and repos into a vault encrypted at rest. Retrieval never uploads. Citations point at local pages."
	},
	{
		icon: WifiOff,
		title: "Offline by default",
		body: "Airplane mode is a supported environment. Sync is optional, explicit, and never implied by a progress spinner."
	},
	{
		icon: Cable,
		title: "OpenAI-compatible API",
		body: "Point existing tools at localhost. Same shapes, your hardware. Keep the editors and agents you already paid for."
	},
	{
		icon: Bot,
		title: "Local agents",
		body: "Agents that read the filesystem, run commands you approve, and write back into the vault — without a remote callback."
	},
	{
		icon: Shield,
		title: "Firm controls",
		body: "Seat-based admin, air-gapped installers, and an audit log that lives next to the data, not in a vendor console."
	}
];
function Features() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "features",
		className: "border-b border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5 py-20 md:px-6 md:py-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium tracking-wide text-muted-foreground",
							children: "Why teams switch"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-title text-foreground",
							children: "Cloud AI is someone else’s computer."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-lead text-muted-foreground",
							children: "Local 1 is a workspace for people who cannot send the work out. Same quality of answer. A different place for the weights to live."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-12 grid gap-4 md:grid-cols-3",
					children: REASONS.map((reason) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl bg-card p-6 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl text-muted-foreground",
								children: reason.num
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 text-lg font-medium text-foreground",
								children: reason.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted-foreground",
								children: reason.body
							})
						]
					}, reason.num))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-20 max-w-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tracking-wide text-muted-foreground",
						children: "The workspace"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-title text-foreground",
						children: "Everything you need, nothing you upload."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
					children: FEATURES.map((feature) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "rounded-xl p-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
							className: "rounded-lg bg-muted/50 p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-10 items-center justify-center rounded-md bg-secondary text-foreground shadow-[var(--shadow-border)]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(feature.icon, {
										className: "size-4",
										strokeWidth: 1.75
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
									className: "mt-4 text-base",
									children: feature.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: feature.body })
							]
						})
					}, feature.title))
				})
			]
		})
	});
}
function ProductFrame() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-xl bg-card p-2 shadow-[var(--shadow-elevated)]",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-hidden rounded-lg bg-background shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 border-b border-border px-3 py-2.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-secondary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-secondary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-secondary" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "flex-1 truncate text-center text-xs text-muted-foreground",
						children: "Local 1 — Northwind vault"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5 rounded-full bg-secondary px-2 py-0.5 text-xs font-medium text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-primary" }), "Private"]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "product-frame-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "border-r border-border bg-muted/60 p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase",
							children: "Vaults"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "space-y-1 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "rounded-sm bg-accent px-2 py-1.5 text-foreground",
									children: "Northwind"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "rounded-sm px-2 py-1.5 text-muted-foreground",
									children: "Clinic notes"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "rounded-sm px-2 py-1.5 text-muted-foreground",
									children: "Source"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase",
							children: "Model"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-sm bg-secondary px-2 py-1.5 text-xs text-foreground",
							children: "Qwen 2.5 32B"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 px-2 text-xs text-muted-foreground",
							children: "On this machine"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 p-4 sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "max-w-sm self-end rounded-lg rounded-br-xs bg-secondary px-3 py-2 text-xs leading-relaxed text-foreground sm:text-sm",
							children: "Summarize the indemnification clause in 8.2. Do not send this file anywhere."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-md rounded-lg rounded-bl-xs bg-muted px-3 py-2.5 text-xs leading-relaxed text-foreground sm:text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-1.5 text-xs font-medium text-muted-foreground",
									children: "Local 1 · 38 tok/s · 0 bytes outbound"
								}),
								"Section 8.2 caps indemnity at twelve months of fees, excludes consequential damages, and requires written notice within 15 days. The cap does not apply to IP infringement or willful misconduct.",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 block text-xs text-muted-foreground",
									children: "Cited: brief.pdf p.14 · addendum p.3"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-auto flex items-center gap-2 rounded-md bg-secondary px-3 py-2 text-xs text-muted-foreground shadow-[var(--shadow-border)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1",
								children: "Ask this vault…"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-sm bg-primary px-2 py-0.5 text-xs font-medium text-primary-foreground",
								children: "Run"
							})]
						})
					]
				})]
			})]
		})
	});
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "product",
		className: "relative overflow-hidden border-b border-border bg-hero-wash",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hero-wash pointer-events-none absolute inset-0",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "noise-bg pointer-events-none absolute inset-0 opacity-5 mix-blend-overlay",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto grid max-w-6xl gap-12 px-5 py-16 md:px-6 md:py-24 lg:grid-cols-2 lg:items-center lg:gap-16 lg:py-28",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stagger-in",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium tracking-wide text-muted-foreground",
							children: "Private preview · macOS, Windows, Linux"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-5 font-display text-display text-foreground",
							children: "The AI that stays in the room."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-lead text-muted-foreground",
							children: "Local 1 runs serious models on the hardware you already own. Briefs, records, and source never leave the machine. The cloud does not get a copy."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row sm:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								className: "pl-6 pr-5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "#access",
									children: ["Request access", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								variant: "outline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#features",
									children: "See how it works"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-10 grid grid-cols-3 gap-4 border-t border-border pt-6 max-w-lg",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted-foreground",
									children: "Outbound"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 font-display text-xl text-foreground",
									children: "0 bytes"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted-foreground",
									children: "First token"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 font-display text-xl text-foreground",
									children: "<40 ms"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted-foreground",
									children: "Install"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 font-display text-xl text-foreground",
									children: "One app"
								})] })
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductFrame, {})]
			})
		]
	});
}
var badgeVariants = cva("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-secondary text-secondary-foreground shadow-[var(--shadow-border)]",
		primary: "bg-primary text-primary-foreground",
		outline: "text-muted-foreground shadow-[var(--shadow-border)]"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		"data-slot": "badge",
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var TIERS = [
	{
		id: "solo",
		name: "Solo",
		monthly: 0,
		yearly: 0,
		blurb: "For personal briefs and late-night drafting.",
		cta: "Start free",
		featured: false,
		features: [
			"1 seat, 1 machine",
			"Community models up to 14B",
			"Personal encrypted vault",
			"Offline chat",
			"Local OpenAI-compatible API"
		]
	},
	{
		id: "pro",
		name: "Pro",
		monthly: 24,
		yearly: 19,
		blurb: "For counsel, founders, and staff engineers.",
		cta: "Start Pro",
		featured: true,
		features: [
			"Everything in Solo",
			"Frontier local models",
			"Agents and approved tools",
			"Unlimited vault size",
			"Priority model updates"
		]
	},
	{
		id: "firm",
		name: "Firm",
		monthly: 48,
		yearly: 38,
		blurb: "For rooms that already have a lock on the door.",
		cta: "Talk to us",
		featured: false,
		features: [
			"Everything in Pro",
			"Shared vault on your LAN",
			"Admin, seats, and audit log",
			"Air-gapped installer",
			"Named success engineer"
		]
	}
];
function Pricing() {
	const [yearly, setYearly] = (0, import_react.useState)(true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "pricing",
		className: "border-b border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5 py-20 md:px-6 md:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-2xl text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tracking-wide text-muted-foreground",
						children: "Pricing"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-title text-foreground",
						children: "Pay for the seat. Not the thought."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-lead text-muted-foreground",
						children: "Run as many prompts as the machine will take. Cancel anytime. Firm includes an air-gapped build."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 inline-flex rounded-lg bg-secondary p-1 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setYearly(false),
							className: cn("h-11 min-w-28 rounded-md px-4 text-sm font-medium transition-[background-color,color] duration-150 ease-out", !yearly ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"),
							children: "Monthly"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setYearly(true),
							className: cn("h-11 min-w-28 rounded-md px-4 text-sm font-medium transition-[background-color,color] duration-150 ease-out", yearly ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"),
							children: "Yearly"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-4 lg:grid-cols-3",
				children: TIERS.map((tier) => {
					const price = yearly ? tier.yearly : tier.monthly;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: cn("flex flex-col rounded-xl p-2", tier.featured && "bg-secondary"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
								className: cn("rounded-lg p-6", tier.featured ? "bg-card" : "bg-muted/40"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
											className: "text-lg",
											children: tier.name
										}), tier.featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "primary",
											children: "Most chosen"
										}) : null]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
										className: "mt-1",
										children: tier.blurb
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-6 flex items-baseline gap-1 text-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-display text-5xl tracking-tight tabular-nums",
											children: ["$", price]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm text-muted-foreground",
											children: tier.id === "firm" ? "/seat/mo" : "/mo"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs text-muted-foreground",
										children: price === 0 ? "No card. Community models." : yearly ? "Billed annually." : "Billed monthly."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
								className: "flex flex-1 flex-col px-6 pt-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-2.5",
									children: tier.features.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start gap-2.5 text-sm text-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "mt-0.5 size-4 shrink-0 text-muted-foreground",
											strokeWidth: 1.75
										}), item]
									}, item))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardFooter, {
								className: "px-6 pb-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									className: "w-full",
									variant: tier.featured ? "default" : "outline",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#access",
										onClick: () => selectPlan(tier.id),
										children: tier.cta
									})
								})
							})
						]
					}, tier.id);
				})
			})]
		})
	});
}
function Logo({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href: "#top",
		className: cn("inline-flex items-center gap-2.5 text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring/70", className),
		"aria-label": "Local 1 home",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex size-8 items-center justify-center rounded-sm bg-primary text-primary-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				viewBox: "0 0 20 20",
				className: "size-4",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M8.2 3.2h2.15v11.2H15V16.8H5.1v-2.4h3.1V3.2Z",
					fill: "currentColor"
				})
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-xl leading-none tracking-tight",
			children: "Local 1"
		})]
	});
}
var COLUMNS = [{
	title: "Product",
	links: [
		{
			href: "#product",
			label: "Overview"
		},
		{
			href: "#features",
			label: "Features"
		},
		{
			href: "#pricing",
			label: "Pricing"
		}
	]
}, {
	title: "Company",
	links: [{
		href: "#stories",
		label: "Stories"
	}, {
		href: "#access",
		label: "Private preview"
	}]
}];
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-10 px-5 py-12 md:flex-row md:items-start md:justify-between md:px-6 md:py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm leading-relaxed text-muted-foreground",
						children: "Private AI for machines you already own. Local 1 keeps the work in the room."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						className: "mt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#access",
							children: "Request access"
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-16",
				children: COLUMNS.map((column) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: column.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: column.links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: link.href,
						className: "text-sm text-foreground hover:text-muted-foreground",
						children: link.label
					}) }, link.href))
				})] }, column.title))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mx-auto max-w-6xl px-5 py-5 text-xs text-muted-foreground md:px-6",
				children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" Local 1. Models run on your hardware. We do not train on your vault."
				]
			})
		})]
	});
}
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
var SheetClose = DialogClose;
var SheetPortal = DialogPortal;
function SheetOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
		className: cn("fixed inset-0 z-50 bg-background/80 data-[state=open]:opacity-100 data-[state=closed]:opacity-0", className),
		...props
	});
}
function SheetContent({ className, children, side = "right", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
		className: cn("fixed z-50 flex h-full w-full max-w-xs flex-col bg-card p-6 shadow-[var(--shadow-elevated)] outline-none", "transition-[transform,opacity] duration-200 ease-out", "data-[state=closed]:duration-150", side === "right" && "inset-y-0 right-0 data-[state=closed]:translate-x-full data-[state=open]:translate-x-0", side === "left" && "inset-y-0 left-0 data-[state=closed]:-translate-x-full data-[state=open]:translate-x-0", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-4 right-4 inline-flex size-11 items-center justify-center rounded-md text-muted-foreground hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring/70",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close menu"
			})]
		})]
	})] });
}
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5 pr-8", className),
		...props
	});
}
function SheetTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
		className: cn("font-display text-xl text-foreground", className),
		...props
	});
}
function SheetDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
var LINKS = [
	{
		href: "#product",
		label: "Product"
	},
	{
		href: "#features",
		label: "Features"
	},
	{
		href: "#pricing",
		label: "Pricing"
	},
	{
		href: "#stories",
		label: "Stories"
	}
];
function SiteNav() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [active, setActive] = (0, import_react.useState)("#top");
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 12);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		const els = [
			"product",
			"features",
			"pricing",
			"stories",
			"access"
		].map((id) => document.getElementById(id)).filter((el) => Boolean(el));
		if (els.length === 0) return;
		const observer = new IntersectionObserver((entries) => {
			const visible = entries.filter((e) => e.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
			if (visible?.target.id) setActive(`#${visible.target.id}`);
		}, {
			rootMargin: "-30% 0px -55% 0px",
			threshold: [
				0,
				.2,
				.5
			]
		});
		els.forEach((el) => observer.observe(el));
		return () => observer.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: cn("sticky top-0 z-40 w-full transition-[background-color,box-shadow] duration-200 ease-out", scrolled ? "bg-background/95 shadow-[var(--shadow-border)]" : "bg-background/70"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: "#product",
			className: "sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-primary-foreground",
			children: "Skip to content"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between px-5 md:px-6",
			"aria-label": "Primary",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "hidden items-center gap-1 md:flex",
					children: LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: link.href,
						className: cn("inline-flex h-11 items-center rounded-md px-3 text-sm font-medium transition-[color,background-color] duration-150 ease-out", active === link.href ? "text-foreground" : "text-muted-foreground hover:text-foreground"),
						children: link.label
					}) }, link.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden md:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#access",
							children: "Request access"
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "icon",
						className: "md:hidden",
						"aria-label": "Open menu",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Local 1" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetDescription, { children: "Private AI on your machine." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-8 flex flex-col gap-1",
						children: LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetClose, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: link.href,
								className: "flex h-11 items-center rounded-md px-2 text-base font-medium text-foreground hover:bg-accent",
								children: link.label
							})
						}) }, link.href))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetClose, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "mt-6 w-full",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#access",
								children: "Request access"
							})
						})
					})
				] })] })
			]
		})]
	});
}
var STORIES = [
	{
		quote: "We stopped pasting contracts into a browser. Local 1 reads the vault on a Mac Mini in the war room. Opposing counsel still thinks we hired another associate.",
		name: "Mara Ellison",
		role: "General Counsel",
		firm: "Hale & Voss LLP",
		initials: "ME"
	},
	{
		quote: "Clinic notes cannot leave the building. The 32B model on our office tower is slower than the cloud — and that is an acceptable sentence to say out loud in a board meeting.",
		name: "Dr. Rohan Iyer",
		role: "Medical Director",
		firm: "Northline Health",
		initials: "RI"
	},
	{
		quote: "I pointed our internal tools at localhost and deleted three SaaS invoices. Same API shape. The weights live next to the CNC programs.",
		name: "Elena Voss",
		role: "Staff Engineer",
		firm: "Fieldline Manufacturing",
		initials: "EV"
	}
];
function Testimonials() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "stories",
		className: "border-b border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5 py-20 md:px-6 md:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tracking-wide text-muted-foreground",
						children: "Stories"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-title text-foreground",
						children: "Built for rooms with a lock on the door."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-lead text-muted-foreground",
						children: "Counsel, clinicians, and operators who cannot file a vendor DPIA every time they want a second pair of eyes."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-4 lg:grid-cols-3",
				children: STORIES.map((story) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "flex flex-col rounded-xl p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
						className: "flex-1 text-sm leading-relaxed text-foreground",
						children: story.quote
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
						className: "mt-8 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-10 items-center justify-center rounded-md bg-secondary font-medium text-sm text-foreground shadow-[var(--shadow-border)]",
							children: story.initials
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-medium text-foreground",
							children: story.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block text-xs text-muted-foreground",
							children: [
								story.role,
								", ",
								story.firm
							]
						})] })]
					})]
				}, story.name))
			})]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "top",
		className: "min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Features, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pricing, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Testimonials, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccessForm, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Home as component };
