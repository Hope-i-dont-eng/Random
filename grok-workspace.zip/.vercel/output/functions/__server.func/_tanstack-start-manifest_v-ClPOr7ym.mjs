//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-ClPOr7ym.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-bJNS4hmJ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-bJNS4hmJ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-hGZqgyag.js"]
	}
} });
//#endregion
export { tsrStartManifest };
